import numpy as np
from scipy.stats import norm
import os
from osgeo import gdal
import glob
import pymannkendall as mk


os.chdir(r'D:/data/monthly/yearly/masked/')
files = glob.glob('*.tif')

evapData = np.empty((71,140,245), dtype = np.float32)

dstmp = gdal.Open('cutted_2015.tif')
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize


n=0

for fn in files[0:]:
    dataset = gdal.Open(fn)
    data = dataset.GetRasterBand(1).ReadAsArray()
    evapData[n,:,:]=data
    dataset = None
    n=n+1

mkData = np.empty((140,245), dtype = np.float32)
x = np.arange(71)+1
for i in np.arange(140):
    for j in np.arange(245):
        x=evapData[:,i,j]
        trend,h,p,z,tau,s,var_s,slope,intercept = mk.trend_free_pre_whitening_modification_test(x,0.05)
        # trend, h, p, z = mk_test(x,0.05)
        mkData[i,j] = z
        print(i,j)

# mkData[np.where(mkData==-0.707527578125)] = -9999.0

driver = gdal.GetDriverByName('GTiff')
outDataset = driver.Create('statistics/evapTFPW-MK_z_years.tif',xSize,ySize,1,gdal.GDT_Float32)
outDataset.SetGeoTransform(gt)
outDataset.SetProjection(pj)
outband = outDataset.GetRasterBand(1)
outband.WriteArray(mkData)
nodataValue = float(mkData[139,244])
outband.SetNoDataValue(nodataValue)
outDataset.FlushCache()
outDataset=None