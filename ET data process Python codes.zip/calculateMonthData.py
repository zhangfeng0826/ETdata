import os
from osgeo import gdal
import numpy as np
import glob
#判断是否闰年，以统计2月是否有29天
def leapyear(year):
    monthdays1 = np.array([31,28,31,30,31,30,31,31,30,31,30,31])
    monthdays2 = np.array([31,29,31,30,31,30,31,31,30,31,30,31])
    if (year % 4) == 0:
       if (year % 100) == 0:
           if (year % 400) == 0:
               return monthdays2
           else:
               return monthdays1
       else:
           return monthdays2
    else:
       return monthdays1

os.chdir(r'E:/data/evaporationdata/ETData/cutted/')
files = glob.glob('*.tif')

dstmp = gdal.Open(files[0])
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize
nodataValue = bandtmp.GetNoDataValue()
dstmp = None


for fn in files[0:]:
    shortname = os.path.splitext(fn)[0]
    year = int(shortname[7:11])
    month = int(shortname[11:13])-1
    # print(year,month)
    monthdays = leapyear(year)

    dataset = gdal.Open(fn)
    band = dataset.GetRasterBand(1)
    data = band.ReadAsArray()

    # data[np.where(data == -9999.0)]=-99.0
    data = np.ma.masked_equal(data,-9999.0)
    #注意，这里获取到的数据是每秒的量，因此如果计算每个月有多少量，需要把data现乘以10800，每天有多少秒
    outdata = data * 10800 * 8 * monthdays[month]

    driver = gdal.GetDriverByName('GTiff')
    outDataset = driver.Create('monthly/'+shortname[7:13]+'.tif',xSize,ySize,1,gdal.GDT_Float32)
    outDataset.SetGeoTransform(gt)
    outDataset.SetProjection(pj)
    outband = outDataset.GetRasterBand(1)
    outband.WriteArray(outdata)
    nodataValue =np.float32(outdata[ySize-1,xSize-1]).item()
    outband.SetNoDataValue(nodataValue)
    outDataset.FlushCache()
    outDataset=None