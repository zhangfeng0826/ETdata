from matplotlib import colors
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker  
import numpy as np
from osgeo import gdal

def imgdata(i):
    filepath = 'E:/data/evaporationdata/ETData/cutted/monthly/yearly/statistics/'
    filename = filepath +'data' + str(i).zfill(2)+'.tif'
    dataset = gdal.Open(filename)
    band = dataset.GetRasterBand(1)
    data = band.ReadAsArray()
    nodataValue = np.float32(data[139,244]).item()
    data = np.ma.masked_equal(data,nodataValue)
    return data


startcolor = '#ff0000'   #红色
midcolor = '#00ff00'     #绿色
endcolor = '#0000ff'     #蓝色
mycmap = matplotlib.colors.LinearSegmentedColormap \
                        .from_list('mycmap ',
                                [startcolor,'#FF7F00','#FFFF00',
                                midcolor,'#00FFFF',endcolor])
matplotlib.cm.register_cmap(cmap=mycmap)

fname = 'E:/data/evaporationdata/ETData/cutted/monthly/yearly/statistics/data01.tif'
ds = gdal.Open(fname)
gt = ds.GetGeoTransform()
extent = (gt[0], gt[0] + ds.RasterXSize * gt[1],
          gt[3] + ds.RasterYSize * gt[5], gt[3])

Nr = 2
Nc = 1

fig, axs = plt.subplots(Nr, Nc,figsize=(6, 6))

# monthname = ['Jan.','Feb.','Mar.','Apr.','May.','Jun.','Jul.','Aug.','Sep.','Oct.','Nov.','Dec.']
monthname = ['1948-2001', '2002-2018']
n=1
images = []
for i in range(Nc):
    for j in range(Nr):
        print(i,j)
        # Generate data with a range that varies from one plot to the next.
        data = imgdata(n)
        images.append(axs[j].imshow(data, cmap=mycmap, extent=extent, origin='upper'))
        axs[j].annotate(monthname[n-1], (76,50))
        axs[ j].label_outer()
        axs[j].yaxis   \
                   .set_major_formatter(  \
                        mticker.FormatStrFormatter('%.0f°N'))
        axs[j].xaxis    \
                   .set_major_formatter(
                        mticker.FormatStrFormatter('%.0f°E'))
        n=n+1
vmin = min(image.get_array().min() for image in images)
vmax = max(image.get_array().max() for image in images)
norm = colors.Normalize(vmin=vmin, vmax=vmax)
for im in images:
    im.set_norm(norm)

position=fig.add_axes([0.15, 0.05, 0.7, 0.03])
cb = fig.colorbar(images[0], ax=axs, cax = position,orientation='horizontal', fraction=.1, aspect=18)
# cb.set_ticks([1.875, 2.75, 3.625, 4.5, 5.375, 6.25, 7.125])
# cb.set_ticklabels([-2.32,-1.64,-1.28,0,1.28,1.64,2.32])

def update(changed_image):
    for im in images:
        if (changed_image.get_cmap() != im.get_cmap()
                or changed_image.get_clim() != im.get_clim()):
            im.set_cmap(changed_image.get_cmap())
            im.set_clim(changed_image.get_clim())

for im in images:
    im.callbacksSM.connect('changed', update)

plt.subplots_adjust(left=0.15, bottom=0.13, right=0.85, top=0.95,wspace=0.05, hspace=0.05)
plt.savefig('D:/data/evap/tfpw_mk/periodET.jpg', dpi=500)
plt.show()