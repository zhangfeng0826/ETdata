import os
from osgeo import gdal
import numpy as np
import glob
"""
将每个年份中从1到12月每个月份的数据进行累积相加，得出每个年份的蒸散总量
并存储为以年份命名的tif文件
年份为1948年到2018年，共71年
"""
os.chdir(r'E:/data/evaporationdata/ETData/cutted/monthly/yearly/')
dstmp = gdal.Open('1948.tif')
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize

totaldata = np.zeros((ySize,xSize), dtype = np.float32)
for n in np.arange(17)+2002:
    print(n)
    fn = str(n)+'.tif'
    dataset = gdal.Open(fn)
    band = dataset.GetRasterBand(1)
    data = band.ReadAsArray()
    totaldata = np.add(data,totaldata)

totaldata = totaldata/17

# std = np.std(totaldata)
# mean = np.mean(totaldata)

# cv4801 = np.divide(std, mean)
# std/mean

totaldata[np.where(totaldata < 0)] = np.float32(totaldata[ySize-1,xSize-1]).item()

driver = gdal.GetDriverByName('GTiff')
outDataset = driver.Create('statistics/data02-182.tif',xSize,ySize,1,gdal.GDT_Float32)
outDataset.SetGeoTransform(gt)
outDataset.SetProjection(pj)
outband = outDataset.GetRasterBand(1)
outband.WriteArray(totaldata)
nodataValue =np.float32(totaldata[ySize-1,xSize-1]).item()
outband.SetNoDataValue(nodataValue)
outDataset.FlushCache()
outDataset=None