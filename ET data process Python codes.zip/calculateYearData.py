import os
from osgeo import gdal
import numpy as np
import glob
"""
将每个年份中从1到12月每个月份的数据进行累积相加，得出每个年份的蒸散总量
并存储为以年份命名的tif文件
年份为1948年到2018年，共71年
"""
os.chdir(r'E:/data/evaporationdata/ETData/cutted/monthly/')
dstmp = gdal.Open('194801.tif')
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize


for n in np.arange(71)+1948:
    print(n)
    totaldata = np.zeros((ySize,xSize), dtype = np.float32)
    files = glob.glob('*'+str(n)+'*.tif')
    nodataValue = 0.0
    for fn in files[0:]:
        dataset = gdal.Open(fn)
        band = dataset.GetRasterBand(1)
        nodataValue = nodataValue+band.GetNoDataValue()
        data = band.ReadAsArray()
        totaldata = np.add(data,totaldata)
        # print(fn)
    driver = gdal.GetDriverByName('GTiff')
    outDataset = driver.Create('yearly/'+str(n)+'.tif',xSize,ySize,1,gdal.GDT_Float32)
    outDataset.SetGeoTransform(gt)
    outDataset.SetProjection(pj)
    outband = outDataset.GetRasterBand(1)
    outband.WriteArray(totaldata)
    outband.SetNoDataValue(nodataValue)
    outDataset.FlushCache()
    outDataset=None

# files = glob.glob('*'+str(1992)+'*.tif')
# for fn in files[0:]:
#     print(fn)

# for fn in files[0:]:
#     shortname = os.path.splitext(fn)[0]
#     dataset = gdal.Open(fn)
#     print(fn)
#     subdatasets = dataset.GetSubDatasets()
#     subdsName= subdatasets[5][0]
#     evap = gdal.Open(subdsName)
#     gdal.Translate('evap/'+shortname+'.tif', evap, format='GTiff', outputType = gdal.GDT_Float32, outputSRS= 'EPSG:4326')
# bandfile = 'GLDAS_NOAH025_M.A200001.021.nc4.SUB.nc4'

# dataset = gdal.Open(bandfile)

# subdatasets = dataset.GetSubDatasets()
# subds= subdatasets[5]
# subdsName = subds[0]
# evap = gdal.Open(subdsName)
# # srs = osr.SpatialReference()
# srs.ImportFromEPSG(4326)
# gdal.Translate('evap2.tif', evap, format='GTiff', outputType = gdal.GDT_Float32, outputSRS= 'EPSG:4326')

# gdal.Warp("projectedevap2.tif",'evap2.tif',dstSRS="EPSG:32650")
# data = evap.ReadAsArray()

# driver = gdal.GetDriverByName('GTiff')
# outDataset = driver.Create('201807.tif',280,240,1,gdal.GDT_Float32)


# gt=[70,0.25,0,60,0,0.25]
# outDataset.SetGeoTransform(gt)

# srs = osr.SpatialReference()
# srs.ImportFromEPSG(4087)
# outDataset.SetProjection(srs.ExportToWkt())
# outband = outDataset.GetRasterBand(1)
# outband.WriteArray(data)

# outDataset.FlushCache()
# outDataset=None

