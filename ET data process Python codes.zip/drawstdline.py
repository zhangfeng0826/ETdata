import os
from osgeo import gdal
import numpy as np
import glob
import matplotlib.pyplot as plt


os.chdir(r'D:/data/monthly/yearly/masked/')
filepath = 'cutted_'


dstmp = gdal.Open('cutted_1948.tif')
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize
nodataValue = bandtmp.GetNoDataValue()

cvEvap = np.empty(71, dtype = np.float32)
sd = np.empty(71, dtype = np.float32)

for i in np.arange(71)+1948:
    filename = filepath + str(i)+'.tif'
    # print(filename)
    dataset = gdal.Open(filename)
    data = dataset.GetRasterBand(1).ReadAsArray()
    data = np.ma.masked_equal(data,nodataValue)
    mean = np.mean(data)
    std = np.std(data)
    if (i == 1968):
        mean = 357.00797487662
        std = 228.73650394849
    sd[i-1948]=std
    dataset = None


print('------------------------')
# cvEvap[20] = 228.73650394849
# print(cvEvap)
# print(np.max(cvEvap[0:54]),np.min(cvEvap[0:54]),np.mean(cvEvap[0:54]))
# print(np.max(cvEvap[54:]),np.min(cvEvap[54:]),np.mean(cvEvap[54:]))
# print(np.arange(54)+1948)
# print(cvEvap[0:55])
# print(np.arange(17)+2002)
# print(cvEvap[55:])
# print(cvEvap)
plt.figure(figsize=(8, 5))

sdmax, sdmin = sd.max(), sd.min()
sd = (sd-sdmin)/(sdmax-sdmin)
# plt.plot(np.arange(71)+1948,cvEvap, label='Trend of cv value')
plt.plot(np.arange(71)+1948,sd, label='Trend of normalized sd value',color='green')
# plt.plot(np.arange(54)+1948,np.zeros(54)+np.mean(cvEvap[0:54]),color='red',linestyle='--')
# plt.plot(np.arange(17)+2002,np.zeros(17)+np.mean(cvEvap[54:]),color='red', linestyle='--', label='Mean of cv value')

plt.ylim(0,1)

# plt.plot(np.zeros(1768-1450)+2002,np.arange(1768-1450)/1000+1.45,color='green')
# plt.plot(np.zeros(1768-1450)+2002,np.arange(1768-1450)/1000+1.45,color='green')
# plt.text(2002,1.7678789,'1.7678789 ',horizontalalignment="right")
# plt.plot(2002,1.7678789,'mo', label='the cv value of 2002')
plt.legend()
plt.savefig('D:/data/evap/tfpw_mk/normalizedsdline.jpg', dpi=500)
plt.show()