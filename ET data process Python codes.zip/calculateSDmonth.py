import numpy as np
from scipy.stats import norm
import os
from osgeo import gdal
import glob
import pymannkendall as mk


os.chdir('D:/data/evap/tfpw_mk/mk/')
files = glob.glob('*.tif')
dstmp = gdal.Open(files[0])
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize
# nodataValue = bandtmp.GetNoDataValue()
smData = np.empty((12,ySize,xSize), dtype = np.float32)
n=0
for fn in files[0:]:
    dataset = gdal.Open(fn)
    data = dataset.GetRasterBand(1).ReadAsArray()
    smData[n,:,:]=data
    dataset = None
    n=n+1
sdData = np.empty((ySize,xSize), dtype = np.float32)
sdData = np.std(smData,axis=0)
# x = np.arange(12)+1
# for i in np.arange(ySize):
#     for j in np.arange(xSize):
#         x=smData[:,i,j]
#         sd = np.std(x)
#         sdData[i,j] = sd
driver = gdal.GetDriverByName('GTiff')
outDataset = driver.Create('sd/sdmonthMKYear.tif',xSize,ySize,1,gdal.GDT_Float32)
outDataset.SetGeoTransform(gt)
outDataset.SetProjection(pj)
outband = outDataset.GetRasterBand(1)
outband.WriteArray(sdData)
nodataValue =np.float32(sdData[ySize-1,xSize-1]).item()
outband.SetNoDataValue(nodataValue)
outDataset.FlushCache()
outDataset=None

