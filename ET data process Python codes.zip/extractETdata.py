import os
from osgeo import gdal
import glob
"""
从原始的netcdf中读取土壤湿度数据，并将其按照月份存储为tif格式的文件。
数据时间为从1948年1月份开始到2018年12月份结束
程序内部不处理时间问题，只是从存储netcdf的文件夹中读取所有.nc4文件
"""
os.chdir(r'e:/data/evaporationdata/')
files = glob.glob('*.nc4')

#获取每个nc4文件内的子数据集的名称，便于后面选择要抽取的数据集
def getsubdatasetname(files):
    dataset = gdal.Open(files[0])
    subdatasets = dataset.GetSubDatasets()
    for s in subdatasets:
        print('名称：{0}\n描述：{1}'.format(*s))
# getsubdatasetname(files)

#根据上面函数中所获取到的子数据集的名称获取该数据集数据，并保存为tif文件
for fn in files[0:]:
    shortname = os.path.splitext(fn)[0]
    dataset = gdal.Open(fn)
    subdatasets = dataset.GetSubDatasets()
    subdsName= 'NETCDF:"' + fn + '":Evap_tavg'#subdatasets[23][0]
    print(fn)
    etdata = gdal.Open(subdsName)
    gdal.Translate('ETData/'+shortname[17:23]+'.tif', etdata, format='GTiff', outputType = gdal.GDT_Float32, outputSRS= 'EPSG:4326')



################################################################
"""
子数据集名称：
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Albedo_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":AvgSurfT_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":CanopInt_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":ECanop_tavg  
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":ESoil_tavg   
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Evap_tavg    
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":LWdown_f_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Lwnet_tavg   
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":PotEvap_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Psurf_f_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qair_f_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qg_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qh_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qle_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qs_acc
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qsb_acc
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Qsm_acc
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Rainf_f_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Rainf_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":RootMoist_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SWE_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SWdown_f_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Snowf_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilMoi0_10cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilMoi100_200cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilMoi10_40cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilMoi40_100cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilTMP0_10cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilTMP100_200cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilTMP10_40cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":SoilTMP40_100cm_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Swnet_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Tair_f_inst
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Tveg_tavg
NETCDF:"GLDAS_NOAH025_M.A194801.020.nc4.SUB.nc4":Wind_f_inst
"""
###########################################################