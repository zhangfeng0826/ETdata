import os
from osgeo import gdal
import numpy as np
import glob
"""
将每个年份中从1到12月每个月份的数据进行累积相加，得出每个年份的蒸散总量
并存储为以年份命名的tif文件
年份为1948年到2018年，共71年
"""
os.chdir(r'E:/data/evaporationdata/ETData/cutted/monthly/yearly/')
dstmp = gdal.Open('1948.tif')
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize


yearData = np.empty((71,ySize,xSize), dtype = np.float32)

for n in np.arange(71)+1948:
    print(n)
    dataset = gdal.Open(str(n)+'.tif')
    band = dataset.GetRasterBand(1)
    data = band.ReadAsArray()
    nodataValue = np.float32(data[139,244]).item()
    data = np.ma.masked_equal(data,nodataValue)
    yearData[n-1948,:,:] = data

# cvtimesdata = np.empty((ySize,xSize), dtype = np.float32)
# for i in np.arange(ySize):
#     for j in np.arange(xSize):
#         x=yearData[:,i,j]
#         sd = np.std(x)
#         mn = np.mean(x)
#         cvtimesdata[i,j] = sd/mn


# yearData = np.mask
# std = np.std(yearData,axis=0)
# mean = np.mean(yearData, axis=0)
# print(std.shape,mean.shape)
cvtimesdata = np.std(yearData,axis=0)/np.mean(yearData, axis=0)

driver = gdal.GetDriverByName('GTiff')
outDataset = driver.Create('statistics/cvtimes.tif',xSize,ySize,1,gdal.GDT_Float32)
outDataset.SetGeoTransform(gt)
outDataset.SetProjection(pj)
outband = outDataset.GetRasterBand(1)
outband.WriteArray(cvtimesdata)
nodataValue =np.float32(cvtimesdata[ySize-1,xSize-1]).item()
outband.SetNoDataValue(nodataValue)
outDataset.FlushCache()
outDataset=None

# files = glob.glob('*'+str(1992)+'*.tif')
# for fn in files[0:]:
#     print(fn)

# for fn in files[0:]:
#     shortname = os.path.splitext(fn)[0]
#     dataset = gdal.Open(fn)
#     print(fn)
#     subdatasets = dataset.GetSubDatasets()
#     subdsName= subdatasets[5][0]
#     evap = gdal.Open(subdsName)
#     gdal.Translate('evap/'+shortname+'.tif', evap, format='GTiff', outputType = gdal.GDT_Float32, outputSRS= 'EPSG:4326')
# bandfile = 'GLDAS_NOAH025_M.A200001.021.nc4.SUB.nc4'

# dataset = gdal.Open(bandfile)

# subdatasets = dataset.GetSubDatasets()
# subds= subdatasets[5]
# subdsName = subds[0]
# evap = gdal.Open(subdsName)
# # srs = osr.SpatialReference()
# srs.ImportFromEPSG(4326)
# gdal.Translate('evap2.tif', evap, format='GTiff', outputType = gdal.GDT_Float32, outputSRS= 'EPSG:4326')

# gdal.Warp("projectedevap2.tif",'evap2.tif',dstSRS="EPSG:32650")
# data = evap.ReadAsArray()

# driver = gdal.GetDriverByName('GTiff')
# outDataset = driver.Create('201807.tif',280,240,1,gdal.GDT_Float32)


# gt=[70,0.25,0,60,0,0.25]
# outDataset.SetGeoTransform(gt)

# srs = osr.SpatialReference()
# srs.ImportFromEPSG(4087)
# outDataset.SetProjection(srs.ExportToWkt())
# outband = outDataset.GetRasterBand(1)
# outband.WriteArray(data)

# outDataset.FlushCache()
# outDataset=None

