from osgeo import gdal, osr
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import matplotlib.ticker as mticker

fname = 'D:/data/evap/tfpw_mk/evapTFPW-MK_z_years_class3.tif'

ds = gdal.Open(fname)
data = ds.ReadAsArray()
gt = ds.GetGeoTransform()

startcolor = '#ff0000'  #红色
midcolor = '#00ff00'     #绿色
endcolor = '#0000ff'     #蓝色
mycmap = matplotlib                        \
                .colors                       \
                .LinearSegmentedColormap   \
                .from_list('mycmap',
                            [startcolor,'#FF7F00','#FFFF00',
                             midcolor,'#00FFFF',endcolor], N=8)

matplotlib.cm.register_cmap(cmap=mycmap)

fig, axs = plt.subplots(figsize=(8, 4.5))

extent = (gt[0], gt[0] + ds.RasterXSize * gt[1],
          gt[3] + ds.RasterYSize * gt[5], gt[3])

nodataValue = np.float32(data[139,244]).item()
data = np.ma.masked_equal(data,nodataValue)

img = axs.imshow(data, extent=extent, origin='upper', cmap = mycmap)
# cbar = fig.colorbar(img, ax=axs, orientation='horizontal', fraction=0.1)

plt.gca().yaxis.set_major_formatter(mticker.FormatStrFormatter('%.0f°N'))
plt.gca().xaxis.set_major_formatter(mticker.FormatStrFormatter('%.0f°E'))

plt.subplots_adjust(left=0.15, bottom=0.15, right=0.85, top=0.95,wspace=0.05, hspace=0.05)

position=fig.add_axes([0.15, 0.1, 0.7, 0.03])
cb = fig.colorbar(img, ax=axs, cax = position,orientation='horizontal', fraction=.1, aspect=18)
cb.set_ticks([1.875, 2.75, 3.625, 4.5, 5.375, 6.25, 7.125])
cb.set_ticklabels([-2.32,-1.64,-1.28,0,1.28,1.64,2.32])

plt.savefig('D:/data/evap/tfpw_mk/MKyeartotal.jpg', dpi=500)

plt.show()