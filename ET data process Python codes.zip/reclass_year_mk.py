import os
from osgeo import gdal, gdalconst
import numpy as np

os.chdir(r'D:/data/evap/tfpw_mk/')
demfn = 'evapTFPW-MK_z_years.tif'
# 读取原始DEM数据
dataset = gdal.Open(demfn)
gt = dataset.GetGeoTransform()
pj = dataset.GetProjection()
band = dataset.GetRasterBand(1)
data = band.ReadAsArray()
xSize = band.XSize
ySize = band.YSize

nodatavalue = np.float32(data[139,144]).item()
print(nodatavalue)
data = np.ma.masked_equal(data,nodatavalue)

# 对原始数据重分类
conlist = [data<= -2.32, (data>-2.32) & (data<=-1.64), (data > -1.64) & (data<=-1.28),  (data > -1.28) & (data<=0) & (data != nodatavalue), (data> 0) & (data<1.28), (data>=1.28) & (data<1.64), (data>=1.64) & (data<2.32),  (data>2.32)]
choiselist = [1, 2, 3, 4, 5, 6, 7, 8]
datareclass = np.select(conlist, choiselist, default = 0)
# 新建分类后的栅格数据
driver = gdal.GetDriverByName('GTiff')
outDataset = driver.Create('evapTFPW-MK_z_years_class2.tif',xSize,ySize,1, gdalconst.GDT_Byte)
outDataset.SetGeoTransform(gt)
outDataset.SetProjection(pj)
outband = outDataset.GetRasterBand(1)
outband.WriteArray(datareclass)
# 建立属性表
rat = gdal.RasterAttributeTable()
# 创建三个属性字段
rat.CreateColumn('Value', gdalconst.GFT_Integer, gdalconst.GFU_Name)
rat.CreateColumn('Count', gdalconst.GFT_Integer, gdalconst.GFU_PixelCount)
rat.CreateColumn('Evaluation', gdalconst.GFT_String, gdalconst.GFU_Generic)
# 设置5行记录，分别存储上面的5个类别
rat.SetRowCount(8)
# 写入第一列，分类后的值[1,2,3,4,5]
rat.WriteArray(choiselist, 0)
# 使用直方图计算分类后每个值的像元数
elevcount = outband.GetHistogram(0, 6, 8, False, False)
# 往属性表中写入第二列数据
rat.WriteArray(elevcount, 1)
# 建立DEM区间范围
conlist = [data, (data>-2.32) & (data<=-1.64), (data > -1.64) & (data<=-1.28),  (data > -1.28) & (data<=0), (data> 0) & (data<1.28), (data>=1.28) & (data<1.64), (data>=1.64) & (data<2.32),  (data>2.32)]

elevrange = ['<= -2.32','-2.32 - -1.64','-1.64 - -1.28','-1.28 - 0','0 - 1.28', '1.28 - 1.64', '-1.64 - 2.32', '>= 2.32']
# 往属性表中写入第三列数据
rat.WriteArray(elevrange, 2)
# 将属性表添加到输出波段
outband.SetDefaultRAT(rat)
# 收尾
outDataset.FlushCache()
outband = None
outDataset = None