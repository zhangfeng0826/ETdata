from matplotlib import colors
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker  
import numpy as np
from osgeo import gdal

def imgdata(i):
    filepath = 'D:/data/evap/tfpw_mk/month/evapTFPW-MK_z_'
    filename = filepath + str(i).zfill(2)+'_month_reclass.tif'
    dataset = gdal.Open(filename)
    band = dataset.GetRasterBand(1)
    data = band.ReadAsArray()
    nodataValue = np.float32(data[139,244]).item()
    data = np.ma.masked_equal(data,nodataValue)
    return data


startcolor = '#ff0000'   #红色
midcolor = '#00ff00'     #绿色
endcolor = '#0000ff'     #蓝色
mycmap = matplotlib.colors.LinearSegmentedColormap \
                        .from_list('mycmap ',
                                [startcolor,'#FF7F00','#FFFF00',
                                midcolor,'#00FFFF',endcolor], N=8)
matplotlib.cm.register_cmap(cmap=mycmap)


fname = 'D:/data/evap/tfpw_mk/month/evapTFPW-MK_z_01_month_reclass.tif'
ds = gdal.Open(fname)
gt = ds.GetGeoTransform()
extent = (gt[0], gt[0] + ds.RasterXSize * gt[1],
          gt[3] + ds.RasterYSize * gt[5], gt[3])

Nr = 4
Nc = 3

fig, axs = plt.subplots(Nr, Nc,figsize=(12, 8))


monthname = ['Jan.','Feb.','Mar.','Apr.','May.','Jun.','Jul.','Aug.','Sep.','Oct.','Nov.','Dec.']
n=1
images = []
for i in range(Nr):
    for j in range(Nc):
        # Generate data with a range that varies from one plot to the next.
        data = imgdata(n)
        print(i,j)
        images.append(axs[i, j].imshow(data, cmap=mycmap, extent=extent, origin='upper'))
        axs[i, j].annotate(monthname[n-1], (76,48))
        axs[i, j].label_outer()
        axs[i, j].yaxis   \
                   .set_major_formatter(  \
                        mticker.FormatStrFormatter('%.0f°N'))
        axs[i, j].xaxis    \
                   .set_major_formatter(
                        mticker.FormatStrFormatter('%.0f°E'))
        n=n+1
vmin = min(image.get_array().min() for image in images)
vmax = max(image.get_array().max() for image in images)
norm = colors.Normalize(vmin=vmin, vmax=vmax)
for im in images:
    im.set_norm(norm)

position=fig.add_axes([0.15, 0.05, 0.7, 0.03])
cb = fig.colorbar(images[0], ax=axs, cax = position,orientation='horizontal', fraction=.1, aspect=18)
cb.set_ticks([1.875, 2.75, 3.625, 4.5, 5.375, 6.25, 7.125])
cb.set_ticklabels([-2.32,-1.64,-1.28,0,1.28,1.64,2.32])

def update(changed_image):
    for im in images:
        if (changed_image.get_cmap() != im.get_cmap()
                or changed_image.get_clim() != im.get_clim()):
            im.set_cmap(changed_image.get_cmap())
            im.set_clim(changed_image.get_clim())

for im in images:
    im.callbacksSM.connect('changed', update)

plt.subplots_adjust(left=0.15, bottom=0.13, right=0.85, top=0.95,wspace=0.05, hspace=0.05)
# plt.savefig('D:/data/evap/tfpw_mk/MKtotal.jpg', dpi=500)
plt.show()