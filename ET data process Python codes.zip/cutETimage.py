import os
from osgeo import gdal
import glob


os.chdir('e:/data/evaporationdata/ETData/')
files = glob.glob('*.tif')
for fn in files[0:]:
    #下面两行用来获取月份，在处理月份数据的时候使用
    shortname = os.path.splitext(fn)[0]
    # print(shortname[17:23])
    dataset = gdal.Open(fn)	
    #下面这行处理月份的时候使用
    gdal.Warp('cutted/cutted_'+shortname+'.tif',dataset, cutlineDSName='../../chinashp/china.shp', cropToCutline=True)
    #下面两行处理年份数据的时候使用
    # shortname, extension = os.path.splitext(fn)
    # gdal.Warp('masked/cutted_'+shortname+'.tif',dataset, cutlineDSName='../../chinashp/ne_110m_admin_0_countries.shp',cutlineWhere=" NAME='China'" ,cropToCutline=True)