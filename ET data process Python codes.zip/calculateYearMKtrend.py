import numpy as np
from scipy.stats import norm
import os
from osgeo import gdal
import glob
import pymannkendall as mk


os.chdir('e:/data/evaporationdata/ETData/cutted/monthly/yearly/')
files = glob.glob('*.tif')
dstmp = gdal.Open(files[0])
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize
# nodataValue = bandtmp.GetNoDataValue()
smData = np.empty((71,ySize,xSize), dtype = np.float32)
n=0
for fn in files[0:]:
    dataset = gdal.Open(fn)
    data = dataset.GetRasterBand(1).ReadAsArray()
    smData[n,:,:]=data
    dataset = None
    n=n+1
mkData = np.empty((ySize,xSize), dtype = np.float32)
x = np.arange(71)+1
for i in np.arange(ySize):
    for j in np.arange(xSize):
        x=smData[:,i,j]
        trend,h,p,z,tau,s,var_s,slope,intercept = mk.trend_free_pre_whitening_modification_test(x,0.05)
        mkData[i,j] = z
driver = gdal.GetDriverByName('GTiff')
outDataset = driver.Create('statistics/MKYear.tif',xSize,ySize,1,gdal.GDT_Float32)
outDataset.SetGeoTransform(gt)
outDataset.SetProjection(pj)
outband = outDataset.GetRasterBand(1)
outband.WriteArray(mkData)
nodataValue =np.float32(mkData[ySize-1,xSize-1]).item()
outband.SetNoDataValue(nodataValue)
outDataset.FlushCache()
outDataset=None

