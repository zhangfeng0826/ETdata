import numpy as np
from scipy.stats import norm
import os
from osgeo import gdal
import glob
import pymannkendall as mk


os.chdir(r'D:/data/monthly/masked/')

evapData = np.empty((71,140,245), dtype = np.float32)

dstmp = gdal.Open('cutted_194801.tif')
gt = dstmp.GetGeoTransform()
pj = dstmp.GetProjection()
bandtmp = dstmp.GetRasterBand(1)
xSize = bandtmp.XSize
ySize = bandtmp.YSize
nodataValue = bandtmp.GetNoDataValue()

for i in np.arange(12)+1:
    for j in np.arange(71)+1948:
        dataset = gdal.Open('cutted_'+str(j)+str(i).zfill(2)+'.tif')
        data = dataset.GetRasterBand(1).ReadAsArray()
        evapData[j-1948,:,:]=data
        dataset = None

    mkData = np.empty((140,245), dtype = np.float32)
    x = np.arange(71)+1
    for m in np.arange(140):
        for n in np.arange(245):
            x=evapData[:,m,n]
            trend,h,p,z,tau,s,var_s,slope,intercept = mk.trend_free_pre_whitening_modification_test(x,0.05)
            mkData[m,n] = z

    nodataValue = np.float32(mkData[139,244]).item()
    fn = str(i).zfill(2)+'.tif'
    print(fn)
    driver = gdal.GetDriverByName('GTiff')
    outDataset = driver.Create('statistics/evapTFPW-MK_z_'+str(i).zfill(2)+'_month.tif',xSize,ySize,1,gdal.GDT_Float32)
    outDataset.SetGeoTransform(gt)
    outDataset.SetProjection(pj)
    outband = outDataset.GetRasterBand(1)
    outband.WriteArray(mkData)
    
    outband.SetNoDataValue(nodataValue)
    outDataset.FlushCache()
    outDataset=None